# atoment
stack-based scripting language

## compile
```sh
cmake .
cmake --build .
```

## usage
```
./atm path/to/script.atm
```

## examples
see examples in tests/
