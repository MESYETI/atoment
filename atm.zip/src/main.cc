#include "app.hh"

int main(int argc, char**argv) {
	App app(argc, argv);

	return 0;
}
