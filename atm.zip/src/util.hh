#pragma once
#include "_components.hh"

namespace Util {
	bool IsNumber(std::string str);
}
