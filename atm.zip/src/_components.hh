#pragma once

// C standard libraries
#include <stdio.h>
#include <stdint.h>

// C++ standard libraries
#include <vector>
#include <string>
#include <fstream>
